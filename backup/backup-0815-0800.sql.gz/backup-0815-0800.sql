--
-- PostgreSQL database dump
--

\restrict AwXPn9fdEjZUmUj0rh6aTGmODZYMP1zeY6uHxH0rhQjCF6ntwKycw3VMDFlSbgB

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: clientes; Type: TABLE; Schema: public; Owner: g_clientes
--

CREATE TABLE public.clientes (
    id integer NOT NULL,
    nombre character varying(255) NOT NULL,
    telefono character varying(50),
    ubicacion_aproximada text,
    foto_domicilio character varying(255),
    comentario text,
    fecha_adquisicion date DEFAULT CURRENT_DATE NOT NULL,
    fecha_ultima_modificacion date DEFAULT CURRENT_DATE NOT NULL,
    last_updated timestamp with time zone DEFAULT now(),
    saldo_actual numeric(10,2) DEFAULT 0.00,
    estado_cliente character varying(50) DEFAULT 'regular'::character varying,
    usuario_sistema_id integer NOT NULL
);


ALTER TABLE public.clientes OWNER TO g_clientes;

--
-- Name: clientes_id_seq; Type: SEQUENCE; Schema: public; Owner: g_clientes
--

CREATE SEQUENCE public.clientes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.clientes_id_seq OWNER TO g_clientes;

--
-- Name: clientes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: g_clientes
--

ALTER SEQUENCE public.clientes_id_seq OWNED BY public.clientes.id;


--
-- Name: movimientos; Type: TABLE; Schema: public; Owner: g_clientes
--

CREATE TABLE public.movimientos (
    id integer NOT NULL,
    cliente_id integer NOT NULL,
    fecha_movimiento date DEFAULT CURRENT_DATE NOT NULL,
    tipo_movimiento character varying(50) NOT NULL,
    monto numeric(10,2) NOT NULL,
    saldo_anterior numeric(10,2) NOT NULL,
    saldo_final numeric(10,2) NOT NULL,
    last_updated timestamp with time zone DEFAULT now(),
    usuario_sistema_id integer NOT NULL,
    CONSTRAINT movimientos_tipo_movimiento_check CHECK (((tipo_movimiento)::text = ANY ((ARRAY['deuda_inicial'::character varying, 'abono'::character varying, 'credito'::character varying])::text[])))
);


ALTER TABLE public.movimientos OWNER TO g_clientes;

--
-- Name: movimientos_id_seq; Type: SEQUENCE; Schema: public; Owner: g_clientes
--

CREATE SEQUENCE public.movimientos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.movimientos_id_seq OWNER TO g_clientes;

--
-- Name: movimientos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: g_clientes
--

ALTER SEQUENCE public.movimientos_id_seq OWNED BY public.movimientos.id;


--
-- Name: usuarios; Type: TABLE; Schema: public; Owner: g_clientes
--

CREATE TABLE public.usuarios (
    id integer NOT NULL,
    username character varying(100) NOT NULL,
    password_hash character varying(255) NOT NULL,
    nombre character varying(255),
    fecha_creacion date DEFAULT CURRENT_DATE NOT NULL
);


ALTER TABLE public.usuarios OWNER TO g_clientes;

--
-- Name: usuarios_id_seq; Type: SEQUENCE; Schema: public; Owner: g_clientes
--

CREATE SEQUENCE public.usuarios_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.usuarios_id_seq OWNER TO g_clientes;

--
-- Name: usuarios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: g_clientes
--

ALTER SEQUENCE public.usuarios_id_seq OWNED BY public.usuarios.id;


--
-- Name: clientes id; Type: DEFAULT; Schema: public; Owner: g_clientes
--

ALTER TABLE ONLY public.clientes ALTER COLUMN id SET DEFAULT nextval('public.clientes_id_seq'::regclass);


--
-- Name: movimientos id; Type: DEFAULT; Schema: public; Owner: g_clientes
--

ALTER TABLE ONLY public.movimientos ALTER COLUMN id SET DEFAULT nextval('public.movimientos_id_seq'::regclass);


--
-- Name: usuarios id; Type: DEFAULT; Schema: public; Owner: g_clientes
--

ALTER TABLE ONLY public.usuarios ALTER COLUMN id SET DEFAULT nextval('public.usuarios_id_seq'::regclass);


--
-- Data for Name: clientes; Type: TABLE DATA; Schema: public; Owner: g_clientes
--

COPY public.clientes (id, nombre, telefono, ubicacion_aproximada, foto_domicilio, comentario, fecha_adquisicion, fecha_ultima_modificacion, last_updated, saldo_actual, estado_cliente, usuario_sistema_id) FROM stdin;
66	LAURA DE CANTEMÓ 			\N		2025-08-06	2025-08-05	2025-08-05 22:49:37.188029-06	0.00	regular	2
67	NANCY HNA DE FÁTIMA 			\N		2025-08-06	2025-08-05	2025-08-05 22:49:37.556237-06	30.00	regular	2
9	TERESA CANCHÉ FALCON			\N	Hija de doña ZENAIDA 	2025-08-06	2025-08-05	2025-08-05 22:49:13.135669-06	100.00	regular	2
10	NORMA DE CANTEMÓ (4/07/2017)			\N		2025-08-06	2025-08-05	2025-08-05 22:49:13.550741-06	50.00	regular	2
13	NORMA (con Felipa Contreras) 			\N		2025-08-06	2025-08-05	2025-08-05 22:49:14.69216-06	130.00	regular	2
14	ELENITA DZUL CONTRERAS 			\N	Cambio de casa	2025-08-06	2025-08-05	2025-08-05 22:49:15.570561-06	120.00	regular	2
19	NOEMY (frente Carranza) 			\N		2025-08-06	2025-08-05	2025-08-05 22:49:17.541437-06	0.00	regular	2
20	NORMA DZUL CUÑADA DE NOEMY 			\N		2025-08-06	2025-08-05	2025-08-05 22:49:17.93618-06	0.00	regular	2
24	SUEMY (hija doña Lupe)			\N		2025-08-06	2025-08-05	2025-08-05 22:49:19.544687-06	0.00	regular	2
26	TERESA (ñeca)			\N		2025-08-06	2025-08-05	2025-08-05 22:49:20.40825-06	40.00	regular	2
27	MIRNA COUOH			\N		2025-08-06	2025-08-05	2025-08-05 22:49:20.795139-06	0.00	regular	2
30	DOÑA MAGDALENA  (Mady)			\N	Desde 2020	2025-08-06	2025-08-05	2025-08-05 22:49:22.050947-06	0.00	regular	2
31	GUADALUPE CANCHÉ vecina doña deisy			\N		2025-08-06	2025-08-05	2025-08-05 22:49:22.418694-06	70.00	regular	2
32	NEYDI CHAN (HIJA DE CECILIA			\N		2025-08-06	2025-08-05	2025-08-05 22:49:22.782981-06	180.00	regular	2
35	REBECA ZULUB CAUICH 			\N		2025-08-06	2025-08-05	2025-08-05 22:49:24.096691-06	340.00	regular	2
37	TERESITA (EMPLEADA DE DOÑA GLORIA)			\N		2025-08-06	2025-08-05	2025-08-05 22:49:24.91227-06	0.00	regular	2
43	MARCELINA CHI EK			\N	(11/11/24)	2025-08-06	2025-08-05	2025-08-05 22:49:27.884398-06	20.00	regular	2
44	ISOLINA HNA DE VIDALIA			\N		2025-08-06	2025-08-05	2025-08-05 22:49:28.290995-06	120.00	regular	2
47	SANDRA HIJA DE DOÑA LUZ			\N		2025-08-06	2025-08-05	2025-08-05 22:49:29.535319-06	0.00	regular	2
49	NORMA (cuñada de Mercedes)			\N		2025-08-06	2025-08-05	2025-08-05 22:49:30.327584-06	0.00	regular	2
50	LOURDES MARISOL 			\N		2025-08-06	2025-08-05	2025-08-05 22:49:30.746926-06	150.00	regular	2
51	SAIDY HIJA DOÑA JULIA			\N	Cantemó 	2025-08-06	2025-08-05	2025-08-05 22:49:31.174061-06	150.00	regular	2
52	JULIA DZUL HNA. DE FELIPA DZUL  VECINA DE ANA 			\N	Cantemó 	2025-08-06	2025-08-05	2025-08-05 22:49:31.522889-06	0.00	regular	2
58	LYSET EK CAUICH HOWITZ 			\N		2025-08-06	2025-08-05	2025-08-05 22:49:33.921686-06	0.00	regular	2
59	ROSY (hermana de serlene)			\N		2025-08-06	2025-08-05	2025-08-05 22:49:34.290014-06	90.00	regular	2
61	MARELLY CANCHE CANUL 			\N		2025-08-06	2025-08-05	2025-08-05 22:49:35.14795-06	670.00	regular	2
63	TERESA cuñada de ADDY canec			\N		2025-08-06	2025-08-05	2025-08-05 22:49:35.971113-06	60.00	regular	2
69	TERESA HNA DE MARÍA LUISA 			\N		2025-08-06	2025-08-05	2025-08-05 22:49:38.423871-06	0.00	regular	2
70	TERESA COUOH. TECLAS			\N		2025-08-06	2025-08-05	2025-08-05 22:49:38.835595-06	0.00	regular	2
71	LAURA CANUL CUÑADA DE FÁTIMA DE CANEC			\N	Casi no compra	2025-08-06	2025-08-05	2025-08-05 22:49:39.24246-06	0.00	regular	2
74	MARTINA DZUL HNA DE ANA			\N		2025-08-06	2025-08-05	2025-08-05 22:49:40.469435-06	50.00	regular	2
25	IDELVIA			\N	suegra de anahy	2025-08-06	2025-08-06	2025-08-06 00:03:47.52986-06	0.00	regular	2
53	ANA		Cantemó	\N	Hna Carolina	2025-08-06	2025-08-06	2025-08-06 08:27:51.957192-06	0.00	regular	2
57	VERÓNICA  CONTRERAS			\N	frente Doña Meldy	2025-08-06	2025-08-05	2025-08-05 23:59:18.744622-06	250.00	regular	2
60	LILIA POLANCO		SN MARCOS 	\N		2025-08-06	2025-08-05	2025-08-05 23:59:19.248327-06	120.00	regular	2
12	ABY CAUICH		Kancab	\N	enfrente de norma Felipa	2025-08-06	2025-08-06	2025-08-06 00:04:44.077287-06	230.00	regular	2
73	ANGÉLICA DZUL 		Canec	\N	Hna, de Fátima Extienda novedades de show 	2025-08-06	2025-08-12	2025-08-12 14:49:54.067502-06	210.00	bueno	2
76	FÁTIMA HNA DE NANCY		Canec	\N		2025-08-06	2025-08-06	2025-08-06 00:06:06.677252-06	410.00	regular	2
17	SUEGRA DE DIANA 		Kancab 	\N	Frente a Carranza	2025-08-06	2025-08-11	2025-08-11 21:42:15.557936-06	90.00	regular	2
11	MIRNA		tienda frente Felipa Contreras	\N	Debe desde (20/06/17)	2025-08-06	2025-08-06	2025-08-06 00:07:06.037352-06	50.00	moroso	2
16	ANA COUOH CHAN		Kancab	\N	con Noemy 	2025-08-06	2025-08-06	2025-08-06 19:08:44.063261-06	130.00	regular	2
54	ALONDRA		Kancab	\N	hna. De DELMY	2025-08-06	2025-08-06	2025-08-06 19:08:44.657498-06	180.00	regular	2
56	Ana 		Kancab	\N	Cuñada de veronica Contreras 	2025-08-06	2025-08-06	2025-08-06 19:08:45.17858-06	20.00	regular	2
64	ADELAIDA 		Canec 	\N	Extienda	2025-08-06	2025-08-06	2025-08-06 19:08:45.816011-06	0.00	regular	2
29	ANA ROSA		Kancab 	\N	Doña mady	2025-08-06	2025-08-06	2025-08-06 19:10:48.483524-06	160.00	regular	2
28	ANAHI CANUL 		Kancab	\N	Doña Mady 	2025-08-06	2025-08-06	2025-08-06 19:11:14.441479-06	0.00	regular	2
21	ANGELICA		Kancab	\N	hna de Noemy	2025-08-06	2025-08-07	2025-08-07 17:52:05.895935-06	40.00	regular	2
78	ANGÉLICA SAN JUAN		Canec 	\N	Casi nunca está 	2025-08-06	2025-08-09	2025-08-09 21:19:59.89873-06	180.00	moroso	2
79	NAYELI DZUL		Canec	\N	Cuñada de angélica san juan	2025-08-06	2025-08-09	2025-08-09 21:20:00.35375-06	130.00	bueno	2
80	MARIANA CANCHÉ 		Canec	\N		2025-08-06	2025-08-09	2025-08-09 21:20:00.797665-06	110.00	bueno	2
18	CASIMIRA 		Kancab 	\N	Frente a Carranza 	2025-08-06	2025-08-11	2025-08-11 21:46:53.410717-06	0.00	regular	2
42	ANTONIA PACAB		Kancab 	\N	Frente al salón 	2025-08-06	2025-08-11	2025-08-11 21:46:53.91596-06	20.00	regular	2
45	CECILIA CANUL EUAN		CANEC	\N	Nuera de doña luz	2025-08-06	2025-08-11	2025-08-11 21:46:54.749465-06	0.00	regular	2
46	CARLA 			\N	nuera doña Luz	2025-08-06	2025-08-12	2025-08-12 14:26:56.710839-06	0.00	regular	2
39	DIANA DZUL CAUICH		Kancab 	\N	Nuera Antonia pacab	2025-08-06	2025-08-12	2025-08-12 14:49:56.155349-06	220.00	regular	2
34	DOÑA DEISY 		Kancab 	\N	Mamá de Jenny 	2025-08-06	2025-08-12	2025-08-12 14:49:47.917587-06	50.00	regular	2
36	DOÑA ISIDORA MAMA DE REBECA 		Kancab	\N	Mamá de rebeca 	2025-08-06	2025-08-12	2025-08-12 14:49:48.432204-06	0.00	regular	2
55	DOÑA MELDY PACAB		Kancab 	\N	Frente Verónica 	2025-08-06	2025-08-12	2025-08-12 14:49:51.086476-06	180.00	regular	2
65	DOÑA CLAUDIA LAURA		Canec 	\N	Canec 	2025-08-06	2025-08-12	2025-08-12 14:49:51.579088-06	0.00	regular	2
75	DIANA 		Canec 	\N	Con la wera	2025-08-06	2025-08-12	2025-08-12 14:49:52.09126-06	30.00	regular	2
48	DOÑA LUZ  		San Marcos 	\N	Tienda san Marcos 	2025-08-06	2025-08-12	2025-08-12 14:49:54.598056-06	0.00	regular	2
23	DOÑA LUPE 		Kancab	\N	Con doña Mady 	2025-08-06	2025-08-12	2025-08-12 14:49:55.118284-06	150.00	regular	2
15	DOÑA DALILA		Kancab	\N	FATIMA 	2025-08-06	2025-08-12	2025-08-12 14:49:55.638577-06	330.00	regular	2
38	GLORIA		Kancab	\N	Tienda anas	2025-08-06	2025-08-12	2025-08-12 23:10:55.503829-06	150.00	regular	2
40	YANILA		Kancab 	\N	Frente al salón 	2025-08-06	2025-08-12	2025-08-12 14:49:57.862148-06	430.00	regular	2
33	JENNY 		Kancab	\N	(tienda) Hija de doña Deisy  	2025-08-06	2025-08-12	2025-08-12 23:14:57.123893-06	600.00	regular	2
81	MARLENE CANCHÉ FALCÓN 			\N	Más o menos	2025-08-06	2025-08-05	2025-08-05 22:49:44.385267-06	400.00	regular	2
82	MARÍA CANCHÉ FALCON			\N	Morosa desde el (22/10/23)	2025-08-06	2025-08-05	2025-08-05 23:41:57.141721-06	260.00	moroso	2
22	DOÑA ANTONIA CAUICH KEYLA		Kancab 	\N	Frente Carranza 	2025-08-06	2025-08-12	2025-08-12 14:49:46.864291-06	105.00	regular	2
83	DOÑA DULCE FALCÓN 		Canec 	\N	Entrada canec 	2025-08-06	2025-08-12	2025-08-12 14:49:52.595449-06	280.00	regular	2
41	YESSICA		Kancab 	\N	Hija de Antonia pacab	2025-08-06	2025-08-12	2025-08-12 14:49:57.009356-06	150.00	regular	2
86	NAYMI DOMÍNGUEZ		Show	\N		2025-08-13	2025-08-12	2025-08-12 23:13:29.901509-06	180.00	regular	2
87	Matilde		Show	\N	Su hija	2025-08-13	2025-08-12	2025-08-12 23:18:40.918756-06	320.00	regular	2
\.


--
-- Data for Name: movimientos; Type: TABLE DATA; Schema: public; Owner: g_clientes
--

COPY public.movimientos (id, cliente_id, fecha_movimiento, tipo_movimiento, monto, saldo_anterior, saldo_final, last_updated, usuario_sistema_id) FROM stdin;
10	9	2025-08-05	deuda_inicial	100.00	0.00	100.00	2025-08-05 22:49:13.135669-06	2
11	10	2025-08-05	deuda_inicial	50.00	0.00	50.00	2025-08-05 22:49:13.550741-06	2
12	11	2025-08-05	deuda_inicial	50.00	0.00	50.00	2025-08-05 22:49:13.916948-06	2
13	12	2025-08-05	deuda_inicial	230.00	0.00	230.00	2025-08-05 22:49:14.309594-06	2
14	13	2025-08-05	deuda_inicial	130.00	0.00	130.00	2025-08-05 22:49:14.69216-06	2
15	14	2025-08-05	deuda_inicial	120.00	0.00	120.00	2025-08-05 22:49:15.570561-06	2
16	15	2025-08-05	deuda_inicial	380.00	0.00	380.00	2025-08-05 22:49:15.942291-06	2
17	16	2025-08-05	deuda_inicial	130.00	0.00	130.00	2025-08-05 22:49:16.306626-06	2
18	17	2025-08-05	deuda_inicial	90.00	0.00	90.00	2025-08-05 22:49:16.704978-06	2
19	18	2025-08-05	deuda_inicial	0.00	0.00	0.00	2025-08-05 22:49:17.134305-06	2
20	19	2025-08-05	deuda_inicial	0.00	0.00	0.00	2025-08-05 22:49:17.541437-06	2
21	20	2025-08-05	deuda_inicial	0.00	0.00	0.00	2025-08-05 22:49:17.93618-06	2
22	21	2025-08-05	deuda_inicial	40.00	0.00	40.00	2025-08-05 22:49:18.294695-06	2
23	22	2025-08-05	deuda_inicial	105.00	0.00	105.00	2025-08-05 22:49:18.764654-06	2
24	23	2025-08-05	deuda_inicial	190.00	0.00	190.00	2025-08-05 22:49:19.177192-06	2
25	24	2025-08-05	deuda_inicial	0.00	0.00	0.00	2025-08-05 22:49:19.544687-06	2
26	25	2025-08-05	deuda_inicial	0.00	0.00	0.00	2025-08-05 22:49:20.000933-06	2
27	26	2025-08-05	deuda_inicial	40.00	0.00	40.00	2025-08-05 22:49:20.40825-06	2
28	27	2025-08-05	deuda_inicial	0.00	0.00	0.00	2025-08-05 22:49:20.795139-06	2
29	28	2025-08-05	deuda_inicial	0.00	0.00	0.00	2025-08-05 22:49:21.144023-06	2
30	29	2025-08-05	deuda_inicial	160.00	0.00	160.00	2025-08-05 22:49:21.630543-06	2
31	30	2025-08-05	deuda_inicial	0.00	0.00	0.00	2025-08-05 22:49:22.050947-06	2
32	31	2025-08-05	deuda_inicial	70.00	0.00	70.00	2025-08-05 22:49:22.418694-06	2
33	32	2025-08-05	deuda_inicial	180.00	0.00	180.00	2025-08-05 22:49:22.782981-06	2
34	33	2025-08-05	deuda_inicial	600.00	0.00	600.00	2025-08-05 22:49:23.281376-06	2
35	34	2025-08-05	deuda_inicial	50.00	0.00	50.00	2025-08-05 22:49:23.693976-06	2
36	35	2025-08-05	deuda_inicial	340.00	0.00	340.00	2025-08-05 22:49:24.096691-06	2
37	36	2025-08-05	deuda_inicial	0.00	0.00	0.00	2025-08-05 22:49:24.473003-06	2
38	37	2025-08-05	deuda_inicial	0.00	0.00	0.00	2025-08-05 22:49:24.91227-06	2
39	38	2025-08-05	deuda_inicial	150.00	0.00	150.00	2025-08-05 22:49:25.332462-06	2
40	39	2025-08-05	deuda_inicial	270.00	0.00	270.00	2025-08-05 22:49:25.731454-06	2
41	40	2025-08-05	deuda_inicial	400.00	0.00	400.00	2025-08-05 22:49:26.116514-06	2
42	41	2025-08-05	deuda_inicial	130.00	0.00	130.00	2025-08-05 22:49:26.5335-06	2
43	42	2025-08-05	deuda_inicial	20.00	0.00	20.00	2025-08-05 22:49:27.472903-06	2
44	43	2025-08-05	deuda_inicial	20.00	0.00	20.00	2025-08-05 22:49:27.884398-06	2
45	44	2025-08-05	deuda_inicial	120.00	0.00	120.00	2025-08-05 22:49:28.290995-06	2
46	45	2025-08-05	deuda_inicial	0.00	0.00	0.00	2025-08-05 22:49:28.666225-06	2
47	46	2025-08-05	deuda_inicial	0.00	0.00	0.00	2025-08-05 22:49:29.113163-06	2
48	47	2025-08-05	deuda_inicial	0.00	0.00	0.00	2025-08-05 22:49:29.535319-06	2
49	48	2025-08-05	deuda_inicial	110.00	0.00	110.00	2025-08-05 22:49:29.91472-06	2
50	49	2025-08-05	deuda_inicial	0.00	0.00	0.00	2025-08-05 22:49:30.327584-06	2
51	50	2025-08-05	deuda_inicial	150.00	0.00	150.00	2025-08-05 22:49:30.746926-06	2
52	51	2025-08-05	deuda_inicial	150.00	0.00	150.00	2025-08-05 22:49:31.174061-06	2
53	52	2025-08-05	deuda_inicial	0.00	0.00	0.00	2025-08-05 22:49:31.522889-06	2
54	53	2025-08-05	deuda_inicial	0.00	0.00	0.00	2025-08-05 22:49:31.977168-06	2
55	54	2025-08-05	deuda_inicial	180.00	0.00	180.00	2025-08-05 22:49:32.388799-06	2
56	55	2025-08-05	deuda_inicial	180.00	0.00	180.00	2025-08-05 22:49:32.785226-06	2
57	56	2025-08-05	deuda_inicial	20.00	0.00	20.00	2025-08-05 22:49:33.196441-06	2
58	57	2025-08-05	deuda_inicial	250.00	0.00	250.00	2025-08-05 22:49:33.534918-06	2
59	58	2025-08-05	deuda_inicial	0.00	0.00	0.00	2025-08-05 22:49:33.921686-06	2
60	59	2025-08-05	deuda_inicial	90.00	0.00	90.00	2025-08-05 22:49:34.290014-06	2
61	60	2025-08-05	deuda_inicial	120.00	0.00	120.00	2025-08-05 22:49:34.660331-06	2
62	61	2025-08-05	deuda_inicial	670.00	0.00	670.00	2025-08-05 22:49:35.14795-06	2
64	63	2025-08-05	deuda_inicial	60.00	0.00	60.00	2025-08-05 22:49:35.971113-06	2
65	64	2025-08-05	deuda_inicial	0.00	0.00	0.00	2025-08-05 22:49:36.384741-06	2
66	65	2025-08-05	deuda_inicial	0.00	0.00	0.00	2025-08-05 22:49:36.793139-06	2
67	66	2025-08-05	deuda_inicial	0.00	0.00	0.00	2025-08-05 22:49:37.188029-06	2
68	67	2025-08-05	deuda_inicial	30.00	0.00	30.00	2025-08-05 22:49:37.556237-06	2
70	69	2025-08-05	deuda_inicial	0.00	0.00	0.00	2025-08-05 22:49:38.423871-06	2
71	70	2025-08-05	deuda_inicial	0.00	0.00	0.00	2025-08-05 22:49:38.835595-06	2
72	71	2025-08-05	deuda_inicial	0.00	0.00	0.00	2025-08-05 22:49:39.24246-06	2
74	73	2025-08-05	deuda_inicial	260.00	0.00	260.00	2025-08-05 22:49:40.08221-06	2
75	74	2025-08-05	deuda_inicial	50.00	0.00	50.00	2025-08-05 22:49:40.469435-06	2
76	75	2025-08-05	deuda_inicial	30.00	0.00	30.00	2025-08-05 22:49:40.875633-06	2
77	76	2025-08-05	deuda_inicial	410.00	0.00	410.00	2025-08-05 22:49:41.29962-06	2
79	78	2025-08-05	deuda_inicial	180.00	0.00	180.00	2025-08-05 22:49:42.096215-06	2
80	79	2025-08-05	deuda_inicial	130.00	0.00	130.00	2025-08-05 22:49:43.14525-06	2
81	80	2025-08-05	deuda_inicial	110.00	0.00	110.00	2025-08-05 22:49:43.50578-06	2
82	81	2025-08-05	deuda_inicial	400.00	0.00	400.00	2025-08-05 22:49:44.385267-06	2
83	82	2025-08-05	deuda_inicial	260.00	0.00	260.00	2025-08-05 22:49:44.876291-06	2
84	83	2025-08-05	deuda_inicial	280.00	0.00	280.00	2025-08-05 22:49:45.279783-06	2
85	73	2025-08-12	abono	-50.00	260.00	210.00	2025-08-12 14:49:54.067502-06	2
86	48	2025-08-12	abono	-110.00	110.00	0.00	2025-08-12 14:49:54.598056-06	2
87	23	2025-08-12	abono	-40.00	190.00	150.00	2025-08-12 14:49:55.118284-06	2
88	15	2025-08-12	abono	-50.00	380.00	330.00	2025-08-12 14:49:55.638577-06	2
89	39	2025-08-12	abono	-50.00	270.00	220.00	2025-08-12 14:49:56.155349-06	2
90	41	2025-08-12	credito	70.00	130.00	200.00	2025-08-12 14:49:56.685874-06	2
91	41	2025-08-12	abono	-50.00	200.00	150.00	2025-08-12 14:49:57.009356-06	2
92	40	2025-08-12	credito	130.00	400.00	530.00	2025-08-12 14:49:57.523486-06	2
93	40	2025-08-12	abono	-100.00	530.00	430.00	2025-08-12 14:49:57.862148-06	2
95	86	2025-08-12	deuda_inicial	180.00	0.00	180.00	2025-08-12 23:13:29.901509-06	2
96	87	2025-08-12	deuda_inicial	320.00	0.00	320.00	2025-08-12 23:18:40.918756-06	2
\.


--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: g_clientes
--

COPY public.usuarios (id, username, password_hash, nombre, fecha_creacion) FROM stdin;
1	zuko	$2b$12$M3K95UwlcyPXh3BRGJuIeuzcHyUxQaE4/c/EXxaSWEA7c9Z9G4hja	Zuriel Canche	2025-08-03
2	sergio	$2b$12$omreW6hX4v3f9RvXkeVqqu155aVsVyanz3x2fUIAlStMljaAmzQgy	Sergio Canche	2025-08-03
\.


--
-- Name: clientes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: g_clientes
--

SELECT pg_catalog.setval('public.clientes_id_seq', 87, true);


--
-- Name: movimientos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: g_clientes
--

SELECT pg_catalog.setval('public.movimientos_id_seq', 96, true);


--
-- Name: usuarios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: g_clientes
--

SELECT pg_catalog.setval('public.usuarios_id_seq', 2, true);


--
-- Name: clientes clientes_pkey; Type: CONSTRAINT; Schema: public; Owner: g_clientes
--

ALTER TABLE ONLY public.clientes
    ADD CONSTRAINT clientes_pkey PRIMARY KEY (id);


--
-- Name: movimientos movimientos_pkey; Type: CONSTRAINT; Schema: public; Owner: g_clientes
--

ALTER TABLE ONLY public.movimientos
    ADD CONSTRAINT movimientos_pkey PRIMARY KEY (id);


--
-- Name: clientes uq_nombre_id_usuario; Type: CONSTRAINT; Schema: public; Owner: g_clientes
--

ALTER TABLE ONLY public.clientes
    ADD CONSTRAINT uq_nombre_id_usuario UNIQUE (nombre, usuario_sistema_id);


--
-- Name: usuarios usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: g_clientes
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_pkey PRIMARY KEY (id);


--
-- Name: usuarios usuarios_username_key; Type: CONSTRAINT; Schema: public; Owner: g_clientes
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_username_key UNIQUE (username);


--
-- Name: movimientos fk_cliente_movimiento; Type: FK CONSTRAINT; Schema: public; Owner: g_clientes
--

ALTER TABLE ONLY public.movimientos
    ADD CONSTRAINT fk_cliente_movimiento FOREIGN KEY (cliente_id) REFERENCES public.clientes(id) ON DELETE CASCADE;


--
-- Name: clientes fk_usuario_sistema; Type: FK CONSTRAINT; Schema: public; Owner: g_clientes
--

ALTER TABLE ONLY public.clientes
    ADD CONSTRAINT fk_usuario_sistema FOREIGN KEY (usuario_sistema_id) REFERENCES public.usuarios(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict AwXPn9fdEjZUmUj0rh6aTGmODZYMP1zeY6uHxH0rhQjCF6ntwKycw3VMDFlSbgB

