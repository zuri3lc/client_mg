--
-- PostgreSQL database dump
--

-- Dumped from database version 16.9
-- Dumped by pg_dump version 16.9

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: clientes; Type: TABLE; Schema: public; Owner: g_clientes
--

CREATE TABLE public.clientes (
    id integer NOT NULL,
    nombre character varying(255) NOT NULL,
    telefono character varying(50),
    ubicacion_aproximada text,
    foto_domicilio character varying(255),
    comentario text,
    fecha_adquisicion date DEFAULT CURRENT_DATE NOT NULL,
    fecha_ultima_modificacion date DEFAULT CURRENT_DATE NOT NULL,
    last_updated timestamp with time zone DEFAULT now(),
    saldo_actual numeric(10,2) DEFAULT 0.00,
    estado_cliente character varying(50) DEFAULT 'regular'::character varying,
    usuario_sistema_id integer NOT NULL
);


ALTER TABLE public.clientes OWNER TO g_clientes;

--
-- Name: clientes_id_seq; Type: SEQUENCE; Schema: public; Owner: g_clientes
--

CREATE SEQUENCE public.clientes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.clientes_id_seq OWNER TO g_clientes;

--
-- Name: clientes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: g_clientes
--

ALTER SEQUENCE public.clientes_id_seq OWNED BY public.clientes.id;


--
-- Name: movimientos; Type: TABLE; Schema: public; Owner: g_clientes
--

CREATE TABLE public.movimientos (
    id integer NOT NULL,
    cliente_id integer NOT NULL,
    fecha_movimiento date DEFAULT CURRENT_DATE NOT NULL,
    tipo_movimiento character varying(50) NOT NULL,
    monto numeric(10,2) NOT NULL,
    saldo_anterior numeric(10,2) NOT NULL,
    saldo_final numeric(10,2) NOT NULL,
    last_updated timestamp with time zone DEFAULT now(),
    usuario_sistema_id integer NOT NULL,
    CONSTRAINT movimientos_tipo_movimiento_check CHECK (((tipo_movimiento)::text = ANY ((ARRAY['deuda_inicial'::character varying, 'abono'::character varying, 'credito'::character varying])::text[])))
);


ALTER TABLE public.movimientos OWNER TO g_clientes;

--
-- Name: movimientos_id_seq; Type: SEQUENCE; Schema: public; Owner: g_clientes
--

CREATE SEQUENCE public.movimientos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.movimientos_id_seq OWNER TO g_clientes;

--
-- Name: movimientos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: g_clientes
--

ALTER SEQUENCE public.movimientos_id_seq OWNED BY public.movimientos.id;


--
-- Name: usuarios; Type: TABLE; Schema: public; Owner: g_clientes
--

CREATE TABLE public.usuarios (
    id integer NOT NULL,
    username character varying(100) NOT NULL,
    password_hash character varying(255) NOT NULL,
    nombre character varying(255),
    fecha_creacion date DEFAULT CURRENT_DATE NOT NULL
);


ALTER TABLE public.usuarios OWNER TO g_clientes;

--
-- Name: usuarios_id_seq; Type: SEQUENCE; Schema: public; Owner: g_clientes
--

CREATE SEQUENCE public.usuarios_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.usuarios_id_seq OWNER TO g_clientes;

--
-- Name: usuarios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: g_clientes
--

ALTER SEQUENCE public.usuarios_id_seq OWNED BY public.usuarios.id;


--
-- Name: clientes id; Type: DEFAULT; Schema: public; Owner: g_clientes
--

ALTER TABLE ONLY public.clientes ALTER COLUMN id SET DEFAULT nextval('public.clientes_id_seq'::regclass);


--
-- Name: movimientos id; Type: DEFAULT; Schema: public; Owner: g_clientes
--

ALTER TABLE ONLY public.movimientos ALTER COLUMN id SET DEFAULT nextval('public.movimientos_id_seq'::regclass);


--
-- Name: usuarios id; Type: DEFAULT; Schema: public; Owner: g_clientes
--

ALTER TABLE ONLY public.usuarios ALTER COLUMN id SET DEFAULT nextval('public.usuarios_id_seq'::regclass);


--
-- Data for Name: clientes; Type: TABLE DATA; Schema: public; Owner: g_clientes
--

COPY public.clientes (id, nombre, telefono, ubicacion_aproximada, foto_domicilio, comentario, fecha_adquisicion, fecha_ultima_modificacion, last_updated, saldo_actual, estado_cliente, usuario_sistema_id) FROM stdin;
\.


--
-- Data for Name: movimientos; Type: TABLE DATA; Schema: public; Owner: g_clientes
--

COPY public.movimientos (id, cliente_id, fecha_movimiento, tipo_movimiento, monto, saldo_anterior, saldo_final, last_updated, usuario_sistema_id) FROM stdin;
\.


--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: g_clientes
--

COPY public.usuarios (id, username, password_hash, nombre, fecha_creacion) FROM stdin;
1	zuko	$2b$12$CafujPnvtZfXxAiZvmm9CeX77YjocEn85EvsrmCP33mFLMbUUlX/u	Zuriel Canche	2025-08-02
\.


--
-- Name: clientes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: g_clientes
--

SELECT pg_catalog.setval('public.clientes_id_seq', 1, false);


--
-- Name: movimientos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: g_clientes
--

SELECT pg_catalog.setval('public.movimientos_id_seq', 1, false);


--
-- Name: usuarios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: g_clientes
--

SELECT pg_catalog.setval('public.usuarios_id_seq', 1, true);


--
-- Name: clientes clientes_pkey; Type: CONSTRAINT; Schema: public; Owner: g_clientes
--

ALTER TABLE ONLY public.clientes
    ADD CONSTRAINT clientes_pkey PRIMARY KEY (id);


--
-- Name: movimientos movimientos_pkey; Type: CONSTRAINT; Schema: public; Owner: g_clientes
--

ALTER TABLE ONLY public.movimientos
    ADD CONSTRAINT movimientos_pkey PRIMARY KEY (id);


--
-- Name: clientes uq_nombre_id_usuario; Type: CONSTRAINT; Schema: public; Owner: g_clientes
--

ALTER TABLE ONLY public.clientes
    ADD CONSTRAINT uq_nombre_id_usuario UNIQUE (nombre, usuario_sistema_id);


--
-- Name: usuarios usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: g_clientes
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_pkey PRIMARY KEY (id);


--
-- Name: usuarios usuarios_username_key; Type: CONSTRAINT; Schema: public; Owner: g_clientes
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_username_key UNIQUE (username);


--
-- Name: movimientos fk_cliente_movimiento; Type: FK CONSTRAINT; Schema: public; Owner: g_clientes
--

ALTER TABLE ONLY public.movimientos
    ADD CONSTRAINT fk_cliente_movimiento FOREIGN KEY (cliente_id) REFERENCES public.clientes(id) ON DELETE CASCADE;


--
-- Name: clientes fk_usuario_sistema; Type: FK CONSTRAINT; Schema: public; Owner: g_clientes
--

ALTER TABLE ONLY public.clientes
    ADD CONSTRAINT fk_usuario_sistema FOREIGN KEY (usuario_sistema_id) REFERENCES public.usuarios(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

